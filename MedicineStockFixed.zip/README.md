# Medicine Stock v1.1

Medicine stock app with a clean horizontal stock table.

Columns:
Sn. | Quantity | Pack | Product | Batch | Expiry | MRP | N. Rate | Sell Rate | Purchase Amount | Sale Amount
