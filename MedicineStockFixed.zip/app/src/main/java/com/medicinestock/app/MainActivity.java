package com.medicinestock.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    EditText qty,pack,product,batch,expiry,mrp,nRate,sellRate;
    TableLayout table;
    TextView summary,purchaseAmount,saleAmount;
    int serial=0, totalUnits=0;

    int dp(float n){ return (int)(n*getResources().getDisplayMetrics().density+0.5f); }

    TextView text(String s,float size){
        TextView t=new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(Color.DKGRAY);
        t.setPadding(dp(8),dp(8),dp(8),dp(8));
        return t;
    }

    EditText field(String hint,int type){
        EditText e=new EditText(this);
        e.setHint(hint); e.setTextSize(17); e.setSingleLine(true);
        e.setInputType(type); e.setPadding(dp(8),0,dp(8),0);
        return e;
    }

    @Override public void onCreate(Bundle b){ super.onCreate(b); build(); }

    void build(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(12),dp(10),dp(12),dp(8));

        TextView title=text("💊 Medicine Stock",28);
        title.setTypeface(null,Typeface.BOLD);
        root.addView(title);

        summary=text("0 medicines • 0 units",18);
        root.addView(summary);

        LinearLayout form=new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);

        qty=field("Quantity",InputType.TYPE_CLASS_NUMBER);
        pack=field("Pack",InputType.TYPE_CLASS_TEXT);
        product=field("Product",InputType.TYPE_CLASS_TEXT);
        batch=field("Batch",InputType.TYPE_CLASS_TEXT);
        expiry=field("Expiry (MM/YYYY)",InputType.TYPE_CLASS_DATETIME);
        mrp=field("MRP",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        nRate=field("N. Rate",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);
        sellRate=field("Sell Rate",InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);

        form.addView(qty);form.addView(pack);form.addView(product);form.addView(batch);
        form.addView(expiry);form.addView(mrp);form.addView(nRate);form.addView(sellRate);

        purchaseAmount=text("Purchase Amount: ₹0.00",16);
        saleAmount=text("Sale Amount: ₹0.00",16);
        form.addView(purchaseAmount);form.addView(saleAmount);

        LinearLayout buttons=new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);
        Button add=new Button(this);add.setText("ADD / PURCHASE");
        Button sale=new Button(this);sale.setText("SALE");
        Button clear=new Button(this);clear.setText("CLEAR");
        buttons.addView(add,new LinearLayout.LayoutParams(0,-2,1));
        buttons.addView(sale,new LinearLayout.LayoutParams(0,-2,1));
        buttons.addView(clear,new LinearLayout.LayoutParams(0,-2,.75f));
        form.addView(buttons);

        Button show=new Button(this);show.setText("SHOW STOCK");form.addView(show);

        ScrollView fs=new ScrollView(this);fs.addView(form);
        root.addView(fs,new LinearLayout.LayoutParams(-1,0,.55f));

        TextView heading=text("Stock Details",22);
        heading.setTypeface(null,Typeface.BOLD);root.addView(heading);

        HorizontalScrollView h=new HorizontalScrollView(this);
        table=new TableLayout(this);table.setStretchAllColumns(false);table.setShrinkAllColumns(false);
        addHeader();
        h.addView(table,new HorizontalScrollView.LayoutParams(dp(1450),-2));
        root.addView(h,new LinearLayout.LayoutParams(-1,0,.45f));

        View.OnFocusChangeListener c=(v,has)->{if(!has)calc();};
        qty.setOnFocusChangeListener(c);nRate.setOnFocusChangeListener(c);sellRate.setOnFocusChangeListener(c);

        add.setOnClickListener(v->addRow(false));
        sale.setOnClickListener(v->addRow(true));
        clear.setOnClickListener(v->clearFields());
        show.setOnClickListener(v->Toast.makeText(this,"Stock shown below",Toast.LENGTH_SHORT).show());
        setContentView(root);
    }

    void addHeader(){
        String[] h={"Sn.","Quantity","Pack","Product","Batch","Expiry","MRP","N. Rate","Sell Rate","Purchase Amount","Sale Amount"};
        TableRow r=new TableRow(this);r.setBackgroundColor(Color.rgb(235,238,240));
        for(String s:h){
            TextView t=text(s,13);t.setTypeface(null,Typeface.BOLD);
            t.setGravity(Gravity.CENTER_VERTICAL);r.addView(t,new TableRow.LayoutParams(dp(130),-2));
        }
        table.addView(r);
    }

    TextView cell(String s){
        TextView t=text(s,13);t.setGravity(Gravity.CENTER_VERTICAL);
        t.setBackgroundResource(android.R.drawable.editbox_background);
        return t;
    }

    void addRow(boolean sale){
        String p=product.getText().toString().trim();
        double q=num(qty);
        if(p.isEmpty()){product.setError("Product name required");return;}
        if(q<=0){qty.setError("Enter quantity");return;}
        calc();serial++;totalUnits+=(int)q;
        String[] a={
            ""+serial,String.format(Locale.US,"%.0f",q),pack.getText().toString(),p,batch.getText().toString(),
            expiry.getText().toString(),money(num(mrp)),money(num(nRate)),money(num(sellRate)),
            money(q*num(nRate)),money(q*num(sellRate))
        };
        TableRow r=new TableRow(this);
        for(String s:a) r.addView(cell(s),new TableRow.LayoutParams(dp(130),-2));
        table.addView(r);
        summary.setText(serial+" medicines • "+totalUnits+" units");
        Toast.makeText(this,sale?"Sale added":"Purchase added",Toast.LENGTH_SHORT).show();
        clearFields();
    }

    String money(double x){return String.format(Locale.US,"₹%.2f",x);}
    double num(EditText e){try{return Double.parseDouble(e.getText().toString().trim());}catch(Exception x){return 0;}}
    void calc(){
        double q=num(qty);
        purchaseAmount.setText("Purchase Amount: "+money(q*num(nRate)));
        saleAmount.setText("Sale Amount: "+money(q*num(sellRate)));
    }
    void clearFields(){
        qty.setText("");pack.setText("");product.setText("");batch.setText("");expiry.setText("");
        mrp.setText("");nRate.setText("");sellRate.setText("");
        purchaseAmount.setText("Purchase Amount: ₹0.00");saleAmount.setText("Sale Amount: ₹0.00");
    }
}
