package com.addi.medicinestock;

import android.app.Activity;
import android.os.Bundle;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout root;
    SharedPreferences db;
    ArrayList<String> products = new ArrayList<String>();

    int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    TextView tv(String text, float size) { TextView t=new TextView(this); t.setText(text); t.setTextSize(size); t.setPadding(dp(10),dp(8),dp(10),dp(8)); return t; }
    Button btn(String text) { Button b=new Button(this); b.setText(text); return b; }
    EditText input(String hint) { EditText e=new EditText(this); e.setHint(hint); e.setTextSize(16); e.setSingleLine(true); e.setPadding(dp(10),dp(5),dp(10),dp(5)); return e; }
    String key(String product) { return "p_" + product.replace(" ", "_"); }
    String clean(String s) { return s.trim(); }
    double num(EditText e) { try { return Double.parseDouble(e.getText().toString().trim()); } catch(Exception ex) { return 0; } }
    String money(double n) { return String.format(Locale.US, "%.2f", n); }

    @Override public void onCreate(Bundle b) { super.onCreate(b); db=getSharedPreferences("MEDICINE_STOCK",MODE_PRIVATE); root=findViewById(android.R.id.content); showHome(); }

    void base(String title) {
        root.removeAllViews();
        TextView h=tv(title,22); h.setTextColor(Color.WHITE); h.setTypeface(null,Typeface.BOLD); h.setGravity(Gravity.CENTER_VERTICAL); h.setBackgroundColor(Color.rgb(15,23,42)); root.addView(h,new LinearLayout.LayoutParams(-1,dp(60)));
    }

    void showHome() {
        base("Medicine Stock");
        int total=0, low=0; Map<String,?> all=db.getAll();
        for(String k:all.keySet()) if(k.startsWith("p_") && k.endsWith("_exists")){String p=k.substring(2,k.length()-7).replace("_"," "); int q=db.getInt(key(p)+"_qty",0); total+=q; if(q<=db.getInt(key(p)+"_limit",10)) low++;}
        LinearLayout stats=new LinearLayout(this); stats.setOrientation(LinearLayout.HORIZONTAL);
        TextView s1=tv("Medicines\n"+countProducts(),16); TextView s2=tv("Units\n"+total,16); TextView s3=tv("Low Stock\n"+low,16); stats.addView(s1,new LinearLayout.LayoutParams(0,dp(75),1)); stats.addView(s2,new LinearLayout.LayoutParams(0,dp(75),1)); stats.addView(s3,new LinearLayout.LayoutParams(0,dp(75),1)); root.addView(stats);
        Button add=btn("ADD / PURCHASE"); Button sale=btn("SALE"); Button stock=btn("SHOW STOCK"); root.addView(add);root.addView(sale);root.addView(stock);
        add.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showAdd();}});
        sale.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showSale();}});
        stock.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showStock();}});
    }
    int countProducts(){int c=0;for(String k:db.getAll().keySet())if(k.startsWith("p_")&&k.endsWith("_exists"))c++;return c;}

    void showAdd(){
        base("Add / Purchase");
        final EditText product=input("Product"); final EditText qty=input("Quantity"); final EditText pack=input("Pack"); final EditText batch=input("Batch"); final EditText expiry=input("Expiry (MM/YYYY)"); final EditText mrp=input("MRP"); final EditText nrate=input("N. Rate"); final EditText sell=input("Sell Rate"); final EditText limit=input("Low Stock Limit (default 10)");
        root.addView(product);root.addView(qty);root.addView(pack);root.addView(batch);root.addView(expiry);root.addView(mrp);root.addView(nrate);root.addView(sell);root.addView(limit);
        Button save=btn("SAVE / ADD STOCK"); Button back=btn("BACK");root.addView(save);root.addView(back);
        save.setOnClickListener(new View.OnClickListener(){public void onClick(View v){String p=clean(product.getText().toString());if(p.length()==0){toast("Product name daalo");return;}String k=key(p);double add=num(qty);if(add<0){toast("Quantity sahi daalo");return;}double old=db.getFloat(k+"_qty",0);double lim=num(limit);if(lim<=0)lim=10;db.edit().putBoolean(k+"_exists",true).putFloat(k+"_qty",(float)(old+add)).putString(k+"_pack",pack.getText().toString()).putString(k+"_batch",batch.getText().toString()).putString(k+"_expiry",expiry.getText().toString()).putFloat(k+"_mrp",(float)num(mrp)).putFloat(k+"_nrate",(float)num(nrate)).putFloat(k+"_sell",(float)num(sell)).putFloat(k+"_limit",(float)lim).apply();toast("Stock saved");showHome();}});
        back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showHome();}});
    }

    void showSale(){
        base("Sale"); final ArrayList<String> names=getNames(); final Spinner spinner=new Spinner(this); ArrayAdapter<String> a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,names);spinner.setAdapter(a);root.addView(spinner);final EditText qty=input("Quantity Sold");root.addView(qty);Button save=btn("SAVE SALE");Button back=btn("BACK");root.addView(save);root.addView(back);
        save.setOnClickListener(new View.OnClickListener(){public void onClick(View v){if(names.size()==0){toast("Pehle product add karo");return;}String p=names.get(spinner.getSelectedItemPosition());String k=key(p);double q=num(qty);double current=db.getFloat(k+"_qty",0);if(q<=0){toast("Quantity daalo");return;}if(q>current){toast("Stock mein itni quantity nahi hai");return;}db.edit().putFloat(k+"_qty",(float)(current-q)).apply();toast("Sale saved. Stock: "+money(current-q));showHome();}});
        back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showHome();}});
    }

    ArrayList<String> getNames(){ArrayList<String> n=new ArrayList<String>();for(String k:db.getAll().keySet())if(k.startsWith("p_")&&k.endsWith("_exists"))n.add(k.substring(2,k.length()-7).replace("_"," "));Collections.sort(n);return n;}

    void showStock(){
        base("Current Stock"); final EditText search=input("Search product");root.addView(search); final LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);root.addView(list);
        final Runnable refresh=new Runnable(){public void run(){list.removeAllViews();String q=search.getText().toString().toLowerCase();for(String p:getNames()){if(q.length()>0&&!p.toLowerCase().contains(q))continue;String k=key(p);double qty=db.getFloat(k+"_qty",0), mrp=db.getFloat(k+"_mrp",0), nr=db.getFloat(k+"_nrate",0), sr=db.getFloat(k+"_sell",0);double purchase=qty*nr,sale=qty*sr;int lim=(int)db.getFloat(k+"_limit",10);TextView t=tv("SN: "+(list.getChildCount()+1)+"\nProduct: "+p+"\nQuantity: "+money(qty)+"   Pack: "+db.getString(k+"_pack","-")+"\nBatch: "+db.getString(k+"_batch","-")+"   Expiry: "+db.getString(k+"_expiry","-")+"\nMRP: ₹"+money(mrp)+"   N. Rate: ₹"+money(nr)+"   Sell Rate: ₹"+money(sr)+"\nPurchase Amount: ₹"+money(purchase)+"\nSale Amount: ₹"+money(sale));t.setTextSize(15);t.setPadding(dp(12),dp(12),dp(12),dp(12));if(qty<=lim)t.setTextColor(Color.rgb(185,28,28));list.addView(t);}}};search.setOnKeyListener(new View.OnKeyListener(){public boolean onKey(View v,int keyCode,android.view.KeyEvent e){refresh.run();return false;}});refresh.run();Button back=btn("BACK");root.addView(back);back.setOnClickListener(new View.OnClickListener(){public void onClick(View v){showHome();}});
    }
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
