package com.medicinestock.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import java.util.Locale;

public class MainActivity extends Activity {

    EditText qty, pack, product, batch, expiry, mrp, nRate, sellRate;
    TextView purchaseAmount, saleAmount, stockSummary, table;
    int serial = 0;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        buildUI();
    }

    TextView tv(String text, int size) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.DKGRAY);
        t.setPadding(10, 8, 10, 8);
        return t;
    }

    EditText field(String hint, int type) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setTextSize(16);
        e.setSingleLine(true);
        e.setInputType(type);
        e.setPadding(12, 4, 12, 4);
        return e;
    }

    void buildUI() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(14, 14, 14, 10);

        TextView title = tv("💊 Medicine Stock", 28);
        title.setTypeface(null, Typeface.BOLD);
        root.addView(title);

        stockSummary = tv("0 medicines • 0 units", 17);
        root.addView(stockSummary);

        LinearLayout form = new LinearLayout(this);
        form.setOrientation(LinearLayout.VERTICAL);

        qty = field("Quantity", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        pack = field("Pack", InputType.TYPE_CLASS_TEXT);
        product = field("Product", InputType.TYPE_CLASS_TEXT);
        batch = field("Batch", InputType.TYPE_CLASS_TEXT);
        expiry = field("Expiry (MM/YYYY)", InputType.TYPE_CLASS_DATETIME);
        mrp = field("MRP", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        nRate = field("N. Rate", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        sellRate = field("Sell Rate", InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        form.addView(qty); form.addView(pack); form.addView(product); form.addView(batch);
        form.addView(expiry); form.addView(mrp); form.addView(nRate); form.addView(sellRate);

        purchaseAmount = tv("Purchase Amount: ₹0.00", 16);
        saleAmount = tv("Sale Amount: ₹0.00", 16);
        form.addView(purchaseAmount);
        form.addView(saleAmount);

        View.OnFocusChangeListener calc = (v, has) -> {
            if (!has) calculate();
        };
        qty.setOnFocusChangeListener(calc);
        nRate.setOnFocusChangeListener(calc);
        sellRate.setOnFocusChangeListener(calc);

        LinearLayout buttons = new LinearLayout(this);
        buttons.setOrientation(LinearLayout.HORIZONTAL);

        Button add = new Button(this);
        add.setText("ADD / PURCHASE");
        Button sale = new Button(this);
        sale.setText("SALE");
        Button clear = new Button(this);
        clear.setText("CLEAR");

        buttons.addView(add, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(sale, new LinearLayout.LayoutParams(0, -2, 1));
        buttons.addView(clear, new LinearLayout.LayoutParams(0, -2, 0.65f));
        form.addView(buttons);

        Button show = new Button(this);
        show.setText("SHOW STOCK");
        form.addView(show);

        ScrollView formScroll = new ScrollView(this);
        formScroll.addView(form);
        root.addView(formScroll, new LinearLayout.LayoutParams(-1, 0, 0.56f));

        TextView heading = tv("Stock Details", 21);
        heading.setTypeface(null, Typeface.BOLD);
        root.addView(heading);

        HorizontalScrollView hs = new HorizontalScrollView(this);
        table = tv("Sn.\tQuantity\tPack\tProduct\tBatch\tExpiry\tMRP\tN. Rate\tSell Rate\tPurchase Amount\tSale Amount", 13);
        table.setTypeface(Typeface.MONOSPACE);
        hs.addView(table);
        root.addView(hs, new LinearLayout.LayoutParams(-1, 0, 0.44f));

        add.setOnClickListener(v -> addStock(false));
        sale.setOnClickListener(v -> addStock(true));
        show.setOnClickListener(v -> Toast.makeText(this, "Stock refreshed", Toast.LENGTH_SHORT).show());
        clear.setOnClickListener(v -> clearFields());

        setContentView(root);
    }

    void calculate() {
        double q = num(qty), n = num(nRate), s = num(sellRate);
        purchaseAmount.setText(String.format(Locale.US, "Purchase Amount: ₹%.2f", q*n));
        saleAmount.setText(String.format(Locale.US, "Sale Amount: ₹%.2f", q*s));
    }

    double num(EditText e) {
        try { return Double.parseDouble(e.getText().toString().trim()); }
        catch(Exception x) { return 0; }
    }

    void addStock(boolean isSale) {
        String p = product.getText().toString().trim();
        if (p.isEmpty()) { product.setError("Product name required"); return; }
        double q = num(qty);
        if (q <= 0) { qty.setError("Enter quantity"); return; }

        calculate();
        serial++;

        double pa = q * num(nRate);
        double sa = q * num(sellRate);

        String row = String.format(Locale.US,
            "%d\t%.0f\t%s\t%s\t%s\t%s\t₹%.2f\t₹%.2f\t₹%.2f\t₹%.2f\t₹%.2f\n",
            serial, q, pack.getText(), p, batch.getText(), expiry.getText(),
            num(mrp), num(nRate), num(sellRate), pa, sa);

        if (isSale) {
            row = "SALE → " + row;
        }
        table.append(row);
        stockSummary.setText(serial + " medicines • " + String.format(Locale.US, "%.0f", q) + " units added");
        clearFields();
        Toast.makeText(this, isSale ? "Sale added" : "Purchase added", Toast.LENGTH_SHORT).show();
    }

    void clearFields() {
        qty.setText(""); pack.setText(""); product.setText(""); batch.setText("");
        expiry.setText(""); mrp.setText(""); nRate.setText(""); sellRate.setText("");
        purchaseAmount.setText("Purchase Amount: ₹0.00");
        saleAmount.setText("Sale Amount: ₹0.00");
    }
}
