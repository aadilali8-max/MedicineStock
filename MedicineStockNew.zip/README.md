# Medicine Stock

Simple Android medicine inventory app.

Fields:
- Sn.
- Quantity
- Pack
- Product
- Batch
- Expiry
- MRP
- N. Rate
- Sell Rate
- Purchase Amount
- Sale Amount

Buttons: ADD / PURCHASE, SALE, SHOW STOCK, CLEAR.
