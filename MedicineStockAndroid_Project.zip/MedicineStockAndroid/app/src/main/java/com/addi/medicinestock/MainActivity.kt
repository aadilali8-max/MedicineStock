package com.addi.medicinestock

import android.app.Activity
import android.os.Bundle
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("stock", MODE_PRIVATE) }
    private val items = mutableMapOf<String, Int>()
    private lateinit var name: EditText; private lateinit var qty: EditText
    private lateinit var list: TextView; private lateinit var summary: TextView
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContentView(R.layout.activity_main)
        name=findViewById(R.id.name); qty=findViewById(R.id.qty); list=findViewById(R.id.list); summary=findViewById(R.id.summary)
        load(); findViewById<Button>(R.id.add).setOnClickListener{change(1)}; findViewById<Button>(R.id.sale).setOnClickListener{change(-1)}; findViewById<Button>(R.id.show).setOnClickListener{render()}; render()
    }
    private fun change(sign:Int){ val n=name.text.toString().trim(); val q=qty.text.toString().toIntOrNull()?:0; if(n.isEmpty()||q<=0){toast("Medicine aur quantity daalo");return}; val now=(items[n]?:0)+sign*q; if(now<0){toast("Stock mein itni quantity nahi hai");return}; items[n]=now; save(); render(); name.text.clear(); qty.text.clear(); toast(if(sign>0)"Purchase saved ✓" else "Sale saved ✓") }
    private fun save(){ val a=JSONArray(); items.forEach{(k,v)->a.put(JSONObject().put("n",k).put("q",v))}; prefs.edit().putString("data",a.toString()).apply() }
    private fun load(){ try{val a=JSONArray(prefs.getString("data","[]")); for(i in 0 until a.length()){val o=a.getJSONObject(i);items[o.getString("n")]=o.getInt("q")}}catch(_:Exception){} }
    private fun render(){ val s=items.entries.sortedBy{it.key.lowercase()}; list.text=if(s.isEmpty())"No medicines yet." else s.joinToString("\n\n"){(k,v)->"💊 $k\nStock: $v"}; summary.text="${items.size} medicines • ${items.values.sum()} units" }
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}
